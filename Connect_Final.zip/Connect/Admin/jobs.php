<?php
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}
include 'connect.php';

// Check if the form is submitted for adding a job post
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['delete_id'])) {
    // Sanitize and validate input data
    $date = $conn->real_escape_string($_POST['date']);
    $company_name = $conn->real_escape_string($_POST['company_name']);
    $job_type = $conn->real_escape_string($_POST['type']);
    $requirements = $conn->real_escape_string($_POST['requirements']);

    // Prepare SQL statement
    $sql = "INSERT INTO job_posts (date, company_name, job_type, requirements) VALUES (?, ?, ?, ?)";
    
    // Create a prepared statement
    $stmt = $conn->prepare($sql);
    
    // Bind parameters to the prepared statement
    $stmt->bind_param("ssss", $date, $company_name, $job_type, $requirements);
    
    // Execute the statement
    if ($stmt->execute()) {
        $message = "Job post added successfully!";
        // Redirect to the same page to prevent resubmission
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        $message = "Error: " . $stmt->error;
    }
    
    // Close the statement
    $stmt->close();
}

// Function to update a job post
function updateJobPost($conn) {
    // Sanitize and validate input data
    $id = $conn->real_escape_string($_POST['id']);
    $date = $conn->real_escape_string($_POST['date']);
    $company_name = $conn->real_escape_string($_POST['company_name']);
    $job_type = $conn->real_escape_string($_POST['type']);
    $requirements = $conn->real_escape_string($_POST['requirements']);

    // Prepare SQL statement
    $sql = "UPDATE job_posts SET date = ?, company_name = ?, job_type = ?, requirements = ? WHERE id = ?";
    
    // Create a prepared statement
    $stmt = $conn->prepare($sql);
    
    // Bind parameters to the prepared statement
    $stmt->bind_param("ssssi", $date, $company_name, $job_type, $requirements, $id);
    
    // Execute the statement
    if ($stmt->execute()) {
        return array('success' => true);
    } else {
        return array('success' => false, 'error' => $stmt->error);
    }
}

// Handle update form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $response = updateJobPost($conn); // Call the function to update job post
    echo json_encode($response); // Return the response as JSON
    exit; // Exit to prevent further processing
}

// Check if a delete request is made
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $delete_id = $conn->real_escape_string($_POST['delete_id']);
    $delete_sql = "DELETE FROM job_posts WHERE id = ?";
    
    // Prepare and execute the delete statement
    if ($delete_stmt = $conn->prepare($delete_sql)) {
        $delete_stmt->bind_param("i", $delete_id);
        
        if ($delete_stmt->execute()) {
            echo json_encode(array('success' => true));
        } else {
            echo json_encode(array('success' => false, 'error' => $delete_stmt->error));
        }
        $delete_stmt->close();
    } else {
        echo json_encode(array('success' => false, 'error' => 'Prepare failed: ' . $conn->error));
    }
    exit; // Exit to prevent further processing
}

// Fetch job posts from the database
$sql = "SELECT * FROM job_posts ORDER BY date DESC";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Posts - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php" class="active">Job Post</a>
            <a href="donation.php">Donation</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>

    <div class="main-content">
        <?php
        if (isset($message)) {
            echo '<div class="message">' . $message . '</div>';
        }
        ?>
        
        <div class="header">
            <h2>Add New Job Post</h2>
        </div>

        <div class="add-job">
            
            <form id="job-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <table class="form-table" >
                    <tr>
                        <td>
                            <label for="date">Job post date:</label>
                            <input type="date" id="date" name="date" required value="<?php echo date('Y-m-d'); ?>">
                        </td>
                        <td>
                            <label for="company_name">Company Name:</label>
                            <input type="text" id="company_name" name="company_name" required placeholder="Enter Company Name" >
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="requirements">Requirements:</label>
                            <textarea id="requirements" name="requirements" rows="4" required placeholder="Enter Requirement Details"></textarea>
                        </td>
                        <td>
                            <label for="type">Job Type:</label>
                            <select id="type" name="type" required>
                                <option value="Full Time">Full Time</option>
                                <option value="Part Time">Part Time</option>
                                <option value="Internship">Internship</option>
                            </select>
                            <button type="submit" id="insert-btn">Add Job Post</button>
                        </td>
                    </tr>
                   
                </table>
            </form>
        </div>

        <div class="jobs-list">
            <h3>Existing Job Posts</h3>
            <table class="jobs-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Date</th>
                        <th>Company Name</th>
                        <th>Job Type</th>
                        <th>Requirements</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["date"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["company_name"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["job_type"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["requirements"]) . "</td>";
                            echo "<td>
                            <button class='view-btn' data-uid='" . htmlspecialchars($row["id"]) . "'>Update</button>
                            <button class='delete-btn' data-uid='" . htmlspecialchars($row["id"]) . "'>Delete</button></td>"; // Delete button
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No job posts found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal for updating job post -->
    <div id="updateModal" style="display:none;">
        <div class="modal-content">
            <span class="close" onclick="document.getElementById('updateModal').style.display='none'">&times;</span>
            <h2>Update Job Post</h2>
            <form id="update-form">
                <input type="hidden" id="update-id" name="id">
                <label for="update-date">Job post date:</label>
                <input type="date" id="update-date" name="date" required>
                <label for="update-company_name">Company Name:</label>
                <input type="text" id="update-company_name" name="company_name" required>
                <label for="update-requirements">Requirements:</label>
                <textarea id="update-requirements" name="requirements" rows="4" required></textarea>
                <label for="update-type">Job Type:</label>
                <select id="update-type" name="type" required>
                    <option value="Full Time">Full Time</option>
                    <option value="Part Time">Part Time</option>
                    <option value="Internship">Internship</option>
                </select>
                <button type="submit">Update Job Post</button>
            </form>
        </div>
    </div>

    <?php
    $conn->close();
    ?>

    <script>
        // Handle insert button click
        document.getElementById('insert-btn').addEventListener('click', function(event) {
            const form = document.getElementById('job-form');
            if (!form.checkValidity()) {
                event.preventDefault(); // Prevent form submission if invalid
                alert("Please fill in all required fields.");
            }
        });

        // Handle delete button click
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function() {
                const deleteId = this.getAttribute('data-uid');
                if (confirm("Are you sure you want to delete this job_post ID "+ deleteId)) {
                    fetch('jobs.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'delete_id=' + deleteId
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert("Job post deleted successfully.");
                            location.reload(); // Reload the page to see the changes
                        } else {
                            alert("Error: " + data.error);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert("An error occurred while deleting the job post. Please try again.");
                    });
                }
            });
        });

        // Handle update button click
        document.querySelectorAll('.view-btn').forEach(button => {
            button.addEventListener('click', function() {
                const jobId = this.getAttribute('data-uid'); // Get the ID from the data-uid attribute
                // Redirect to the update page
                window.location.href = 'update_job_post.php?id=' + jobId;
            });
        });

        // Handle update form submission
        document.getElementById('update-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission
            const formData = new FormData(this);
            fetch('update_job_post.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("Job post updated successfully.");
                    location.reload(); // Reload the page to see the changes
                } else {
                    alert("Error: " + data.error);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred while updating the job post. Please try again.");
            });
        });
    </script>

    <script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</body>
</html>

<?php include 'footer.php'; ?>