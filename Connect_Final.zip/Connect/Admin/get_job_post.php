Admin/get_job_post.php
<?php
include 'connect.php';

// Check if the ID is provided
if (isset($_GET['id'])) {
    $id = $conn->real_escape_string($_GET['id']);
    $sql = "SELECT * FROM job_posts WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $job_post = $result->fetch_assoc();
        echo json_encode(array('success' => true, 'job_post' => $job_post));
    } else {
        echo json_encode(array('success' => false, 'error' => 'Job post not found.'));
    }
    $stmt->close();
} else {
    echo json_encode(array('success' => false, 'error' => 'No ID provided.'));
}

$conn->close();
?>