<?php 
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="donation.php">Donation</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php" class="active">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <h2>Help and Instructions</h2>
        </div>
        <div class="instruction-container">
            <h3>How to Use the Alumni System</h3>
            
            <div class="instruction-item">
                <h4>1. Logging into the Alumni System</h4>
                <p>To log in, use your credentials provided by the system admin. If you have forgotten your password, use the "Forgot Password" option or contact the admin.</p>
            </div>
            
            <div class="instruction-item">
                <h4>2. Updating Your Profile</h4>
                <p>Click on "Profile" in the top navigation menu. You can update your personal information, such as contact details, by clicking the "Edit Profile" button and then saving your changes.</p>
            </div>
            
            <div class="instruction-item">
                <h4>3. Viewing Upcoming Events</h4>
                <p>Navigate to the "Events" from the top menu to view all the upcoming alumni events. You can view details, dates, and RSVP for any events you're interested in.</p>
            </div>

            <div class="instruction-item">
                <h4>4. Applying for Job Postings</h4>
                <p>In the "Job Post" section, browse available job opportunities posted by alumni or companies. Click "Apply" to submit your application for any job listing.</p>
            </div>

            <div class="instruction-item">
                <h4>5. Viewing the Alumni Gallery</h4>
                <p>To view photos of alumni, click on the "Gallery" link in the top menu. Here, you will see a collection of images related to alumni and past events.</p>
            </div>

            <div class="instruction-item">
                <h4>6. Updating Your Profile</h4>
                <p>To update your profile, navigate to the "Profile" section from the top navigation menu. Here, you can edit your personal information and save the changes.</p>
            </div>

            <div class="instruction-item">
                <h4>7. Logging Out</h4>
                <p>To log out of the system, simply click the "Logout" link in the top navigation menu.</p>
            </div>

        </div>
    </div>

    <script>
        function toggleNav() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
                x.className += " responsive";
                openNav();
            } else {
                x.className = "topnav";
                closeNav();
            }
        }

        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
    </script>

    <script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</body>
</html>

<?php include 'footer.php'; ?>