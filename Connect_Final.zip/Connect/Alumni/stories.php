<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: ../home.php');
    exit;
}
include 'connect.php';

// Check if the form is submitted for adding a story
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['delete_id'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $date = $conn->real_escape_string($_POST['date']);

    // Prepare SQL statement
    $sql = "INSERT INTO stories (title, description, date) VALUES (?, ?, ?)";
    
    // Create a prepared statement
    $stmt = $conn->prepare($sql);
    
    // Bind parameters to the prepared statement
    $stmt->bind_param("sss", $title, $description, $date);
    
    // Execute the statement
    if ($stmt->execute()) {
        $message = "Story added successfully!";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        $message = "Error: " . $stmt->error;
    }
    
    // Close the statement
    $stmt->close();
}

// Fetch stories from the database
$sql = "SELECT * FROM stories ORDER BY date DESC";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Stories - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="events.php">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="Stories.php" class="active">Stories</a>
            <a href="donation.php">Donation</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>
    <div class="main-content">
        <div class="header">
            <h2>Add New Story</h2>
        </div>

        <div class="add-story">
            <form id="story-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <table class="form-table">
                    <tr>
                        <td>
                            <label for="title">Title:</label>
                            <input type="text" id="title" name="title" required placeholder="Enter Story Title">
                        </td>
                        <td>
                            <label for="date">Date:</label>
                            <input type="date" id="date" name="date" required value="<?php echo date('Y-m-d'); ?>">
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <label for="description">Description:</label>
                            <textarea id="description" name="description" rows="4" required placeholder="Enter Story Description"></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <button type="submit" id="insert-btn">Add Story</button>
                        </td>
                    </tr>
                </table>
            </form>
        </div>

        <div class="stories-list">
            <h3>Existing Stories</h3>
            <table class="stories-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["title"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["description"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["date"]) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No stories found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php
    $conn->close();
    ?>

    <script>
        document.getElementById('insert-btn').addEventListener('click', function(event) {
            const form = document.getElementById('story-form');
            if (!form.checkValidity()) {
                event.preventDefault();
                alert("Please fill in all required fields.");
            }
        });
    </script>
</body>
</html>

<?php include 'footer.php'; ?>
