<?php
session_start();
$user_id = isset($_POST['user_id']) ? $_POST['user_id'] : 'Guest';
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;

// Include the database connection
include 'connect.php'; // Ensure this path is correct

// Handle delete request
// if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
//     $uid = intval($_POST['delete_id']); // Sanitize input
//     // $sql = "DELETE FROM users WHERE id = ?;
//     $sql = "DELETE FROM users WHERE id = ? AND user_type IN ('alumni', 'student')";

//     $stmt = $conn->prepare($sql);
//     $stmt->bind_param("i", $uid);
    
//     if ($stmt->execute()) {
//         echo json_encode(array('success' => true)); // Use array() instead of []
//         exit; // Exit after handling the delete
//     } else {
//         echo json_encode(array('success' => false, 'error' => 'Failed to delete user.')); // Use array() instead of []
//         exit; // Exit after handling the error
//     }
// }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Records - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php" class="active">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <h2>Alumni Records</h2>
        </div>

        <!-- <div class="alumni-list">
            <table >
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Date of Birth</th>
                        <th>Gender</th>
                        <th>College ID</th>
                        <th>Contact</th>
                        <th>Passing Year</th>
                        <th>Work Status</th>
                        <th>User Type</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    try {
                        // Fetch data from users table
                        $sql = "SELECT * FROM users";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($user = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>{$user['id']}</td>
                                        <td>{$user['email']}</td>
                                        <td>{$user['name']}</td>
                                        <td>{$user['date_of_birth']}</td>
                                        <td>{$user['gender']}</td>
                                        <td>{$user['college_id']}</td>
                                        <td>{$user['contact']}</td>
                                        <td>{$user['passing_year']}</td>
                                        <td>{$user['work_status']}</td>
                                        <td>{$user['user_type']}</td>
                                        <td>
                                            
                                            <button class='delete-btn' data-uid='{$user['id']}'>Delete</button>
                                        </td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='11'>No users found.</td></tr>";
                        }
                    } catch (Exception $e) {
                        echo "Error: " . $e->getMessage();
                    }
                    ?>
                </tbody>
            </table>
        </div> -->
    </div>

    <script>
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function() {
                var uid = this.getAttribute('data-uid');
                if (confirm('Are you sure you want to delete this user Id '+ uid )) {
                    fetch('', { // Send to the same file
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `delete_id=${uid}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('User deleted successfully');
                            this.closest('tr').remove(); // Remove the row from the table
                        } else {
                            alert('Error: ' + data.error);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while deleting the user.');
                    });
                }
            });
        });

        function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                fetch('logout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=logout'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert("You have been successfully logged out.");
                        window.location.href = '../home.php'; 
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert("An error occurred during logout. Please try again.");
                });
            }
        }
    </script>

</body>
</html>

<?php include 'footer.php'; ?>