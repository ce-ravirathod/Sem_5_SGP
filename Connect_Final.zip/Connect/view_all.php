<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CE Connect - View All</title>
    <link href="styles/common.css" rel="stylesheet">
    <link href="styles/view_all.css" rel="stylesheet">
    <link href="styles/header_footer.css" rel="stylesheet">
    <script src="js/main.js"></script>
</head>
<body>
    <nav class="header-topnav">
        <div class="header-logo">
            <img src="https://d2lk14jtvqry1q.cloudfront.net/media/large_Charotar_University_of_Science_and_Technology_CHARUSAT_Anand_fdce544903_1202e15c5f.png" alt="CHARUSAT Logo">
            <span>CE Connect</span>
        </div>
        <div class="header-menu-icon" onclick="toggleMenu()">&#9776;</div>
        <div class="header-topnav-right">
            <a href="home.php" class="active">Home</a>
            <a href="aboutus.php">About Us</a>
            <a href="donation.php">Donation</a>
            <a href="Admin/login.php">Login</a>
        </div>
    </nav>

    <main class="view-all-container">
       
        </style>
        <a href="home.php" class="back-button"></a>
        <h1 class="view-all-title">All Updates</h1>
        
        <div class="view-all-grid">
            <!-- Static content replacing PHP-generated items -->
            <div class="view-all-item">
                <div class="item-type">News</div>
                <h2 class="item-title">New Campus Building Inaugurated</h2>
                <p class="item-subtitle">State-of-the-art facility opens its doors</p>
                <p class="item-date">2023-05-15</p>
                <a href="#" class="item-read-more">Read More</a>
            </div>
            <div class="view-all-item">
                <div class="item-type">Achievement</div>
                <h2 class="item-title">Alumni Wins Prestigious Award</h2>
                <p class="item-subtitle">Recognition for groundbreaking research</p>
                <p class="item-date">2023-06-02</p>
                <a href="#" class="item-read-more">Read More</a>
            </div>
            <div class="view-all-item">
                <div class="item-type">Event</div>
                <h2 class="item-title">Annual Tech Symposium</h2>
                <p class="item-subtitle">Exploring the future of technology</p>
                <p class="item-date">2023-07-10</p>
                <a href="#" class="item-read-more">Read More</a>
            </div>
            <div class="view-all-item">
                <div class="item-type">Story</div>
                <h2 class="item-title">From Campus to Silicon Valley</h2>
                <p class="item-subtitle">An inspiring journey of a CE Connect alumnus</p>
                <p class="item-date">2023-06-20</p>
                <a href="#" class="item-read-more">Read More</a>
            </div>
        </div>
    </main>
    <div id="popupOverlay" class="popup-overlay">
        <div class="popup-content">
            <span class="close-popup">&times;</span>
            <h2 id="popupTitle"></h2>
            <p id="popupSubtitle"></p>
            <p id="popupDate"></p>
            <div id="popupContent"></div>
        </div>
    </div>
    
    <?php include('footer.php'); ?>
</body>
</html>