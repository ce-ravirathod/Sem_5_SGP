<?php
session_start();
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password, user_type FROM users WHERE email = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    // Debug: Check if email exists
    // echo "Rows found: " . $stmt->num_rows . "<br>";

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $stored_password, $user_type);
        $stmt->fetch();

        // Debug: Print stored and input password/hash
        // echo "Stored password/hash: " . $stored_password . "<br>";
        // echo "Input password: " . $password . "<br>";
        // echo "Input hash: " . md5($password) . "<br>";

        // Check if the stored password is already hashed
        if (strlen($stored_password) == 32 && ctype_xdigit($stored_password)) {
            // Stored password is likely an MD5 hash
            $password_correct = (md5($password) === $stored_password);
        } else {
            // Stored password is likely plain text
            $password_correct = ($password === $stored_password);
        }

        if ($password_correct) {
            $_SESSION['user_id'] = $id;
            $_SESSION['user_type'] = $user_type;

            echo "Login successful. User ID: " . $_SESSION['user_id'] . ", User Type: " . $_SESSION['user_type'] . "<br>";

            // If the password was plain text, update it to a hashed version
            if (strlen($stored_password) != 32 || !ctype_xdigit($stored_password)) {
                $hashed_password = md5($password);
                $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $update_stmt->bind_param("si", $hashed_password, $id);
                $update_stmt->execute();
                $update_stmt->close();
                echo "Password has been hashed and updated in the database.<br>";
            }

            switch ($user_type) {
                case 'student':
                    header("Location: student_dashboard.php");
                    break;
                case 'alumni':
                    header("Location: alumni_dashboard.php");
                    break;
                case 'admin':
                    header("Location: index.php");
                    break;
                default:
                    $error = "Invalid user type";
            }
            exit();
        } else {
            $error = "Invalid email or password (password mismatch)";
        }
    } else {
        $error = "Invalid email or password (email not found)";
    }

    $stmt->close();
    $conn->close();
}

// Display error message
if(isset($error)) {
    echo "<p style='color: red;'>$error</p>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHARUSAT - Login</title>
    <link rel="stylesheet" href="login.css">
    <style>
        .required::after {
            content: " *";
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <div class="logo-circle">
                <img src="https://admission.charusat.ac.in/View%20Assets/images/University_Hero.png" alt="CHARUSAT Logo">
            </div>
        </div>
        <div class="right-panel">
            <div class="login-form">
                <div class="login-logo">
                    <img src="https://d2lk14jtvqry1q.cloudfront.net/media/large_Charotar_University_of_Science_and_Technology_CHARUSAT_Anand_fdce544903_1202e15c5f.png" alt="CHARUSAT Logo">
                </div>
                <h2>Login</h2>
    <?php if(isset($error)) { echo "<p style='color: red;'>$error</p>"; } ?>
    <form action="login.php" method="POST">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>
        <button type="submit">Login</button>
    </form>
                <?php
                if (isset($error)) {
                    echo "<p class='error'>$error</p>";
                }
                ?>
                <div class="links-container">
                    <div class="signup">
                        <a href="register.php">Sign Up</a>
                    </div>
                    <div class="forgot-password">
                        <a href="#">Forgot Password?</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>