<?php
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Charusat Alumni System - Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .dashboard-card a {
    display: inline-block; /* Make link a block element for padding */
    padding: 10px 15px; /* Add padding for better clickability */
    background-color: #3498db; /* Background color for the link */
    color: #ffffff; /* Text color */
    border-radius: 5px; /* Rounded corners */
    text-decoration: none; /* Remove underline */
    transition: background-color 0.3s, transform 0.3s; /* Smooth transitions */
}

.dashboard-card a:hover {
    background-color: #2980b9; /* Darker background on hover */
    transform: scale(1.05); /* Slightly enlarge link on hover */
}

.dashboard-card a:active {
    background-color: #1abc9c; /* Different color when active */
}

    </style>
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php" >Job Post</a>
            <a href="syllabus.php"  class="active">Syllabus</a>
            <a href="gallery.php" >Gallery</a>
            <a href="help.php" >Help</a>
            <a href="profile.php" >Profile</a>
            <a  onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
        </div>
        </div>
    </div>
    <div class="main-content">
    <div class="header">
            <h2>All Subject Syllabus</h2>
        </div>
    
        <div class="dashboard-container">
            <div class="dashboard-card">
                <h3>CE Department  </h3>
                <a href="https://sites.google.com/charusat.ac.in/cspitce/home" target="_blank" rel="noopener noreferrer">CE Dept</a>
            </div>
            <div class="dashboard-card">
                <h3>Faculty Projects</h3>
                <a href="https://sites.google.com/charusat.ac.in/cspitce/faculty-projects" target="_blank" rel="noopener noreferrer">Faculty Projects</a>
            </div>
            <div class="dashboard-card">
                <h3>1st Year Syllabus</h3>
                <a href="https://sites.google.com/charusat.ac.in/cspitce/courses/1st-year" target="_blank" rel="noopener noreferrer">1st Year</a>
            </div>
            <div class="dashboard-card">
                <h3>3rd Year Syllabus</h3>
                <a href="https://sites.google.com/charusat.ac.in/cspitce/courses/3rd-year" target="_blank" rel="noopener noreferrer">3rd Year</a>
            </div>
            <div class="dashboard-card">
                <h3>2nd Year Syllabus</h3>
                <a href="https://sites.google.com/charusat.ac.in/cspitce/courses/2nd-year" target="_blank" rel="noopener noreferrer">2nd Year</a>
            </div>
            <div class="dashboard-card">
                <h3>4th Year Syllabus</h3>
                <a href="https://sites.google.com/charusat.ac.in/cspitce/courses/4th-year" target="_blank" rel="noopener noreferrer">4th Year</a>
            </div>
        </div>
    </div>
  
    
    
   

    <script>
        function toggleNav() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
                x.className += " responsive";
                openNav();
            } else {
                x.className = "topnav";
                closeNav();
            }
        }

        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
    </script>
      <script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</body>
</html>

<?php include 'footer.php'; ?>
<!-- 

CREATE TABLE alumni (
    user_id INT PRIMARY KEY,
    name VARCHAR(255),
    date_of_birth DATE,
    gender ENUM('Male', 'Female', 'Other'),
    college VARCHAR(255),
    work_status VARCHAR(100),
    profile_photo VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(id)
); -->