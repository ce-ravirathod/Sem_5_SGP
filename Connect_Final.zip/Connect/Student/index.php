<?php
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}
include 'connect.php';
// $user_id = isset($_SESSION['email']) ? $_SESSION['email'] : 'Guest';

// Initialize user_name and user_email
$user_name = 'Guest';
$user_email = '';

// Check if email is set in the session
if (isset($_SESSION['email'])) {
    $email = $conn->real_escape_string($_SESSION['email']);
    $user_email = htmlspecialchars($email); // Store the email for display
    
    // Query to fetch the user's name based on the email
    $query = "SELECT name FROM users WHERE email = '$email'";
    $result = $conn->query($query);
    
    // If the query is successful and a user is found
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $user_name = $user['name']; // Set user_name to the fetched name
    }
} 

$sql = "SELECT COUNT(*) AS total_alumni FROM users WHERE user_type = 'Alumni'";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $total_alumni = $row['total_alumni'];
    // echo "Total Alumni: " . $total_alumni;
} else {
    echo "Error: " . $conn->error;
}

// Query to fetch total events
$sql_events = "SELECT COUNT(*) AS total_events FROM events"; // New query to count events
$result_events = $conn->query($sql_events);

if ($result_events) {
    $row_events = $result_events->fetch_assoc();
    $total_events = $row_events['total_events']; // Store the total events count
} else {
    echo "Error: " . $conn->error;
}

// Query to fetch total active users (students + alumni)
$sql_active_users = "SELECT COUNT(*) AS total_active_users FROM users WHERE user_type IN ('Student', 'Alumni')";
$result_active_users = $conn->query($sql_active_users);

if ($result_active_users) {
    $row_active_users = $result_active_users->fetch_assoc();
    $total_active_users = $row_active_users['total_active_users']; // Store the total active users count
} else {
    echo "Error: " . $conn->error;
}

// Query to fetch total job posts
$sql_job_posts = "SELECT COUNT(*) AS total_job_posts FROM job_posts"; // New query to count job posts
$result_job_posts = $conn->query($sql_job_posts);

if ($result_job_posts) {
    $row_job_posts = $result_job_posts->fetch_assoc();
    $total_job_posts = $row_job_posts['total_job_posts']; // Store the total job posts count
} else {
    echo "Error: " . $conn->error;
}

// Fetch statistics (replace with actual database queries)
// $total_alumni = 5000;
// $total_events = 15;
$total_news = 25;
// $total_job_posts = 50;
// $total_active_users = 750;
$total_donations = 100000;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Charusat Alumni System - Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <style>
       
    </style>
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php" class="active">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php" >Job Post</a>
            <a href="syllabus.php">Syllabus</a>
            <a href="gallery.php" >Gallery</a>
            <a href="help.php" >Help</a>
            <a href="profile.php" >Profile</a>
            <a  onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
        </div>
        </div>
    </div>
    <div class="main-content">
    <div class="header">
            <h2>Student Dashboard</h2>
        </div>
        
        <h3>Welcome, <?php echo $user_name; ?>!</h3>
        <div class="dashboard-container">
            <div class="dashboard-card">
                <h3>Total Alumni</h3>
                <p><?php echo number_format($total_alumni); ?>+</p>
            </div>
            <div class="dashboard-card">
                <h3>Total Events</h3>
                <p><?php echo number_format($total_events); ?>+</p>
            </div>
            <div class="dashboard-card">
                <h3>Total Job Posts</h3>
                <p><?php echo number_format($total_job_posts); ?>+</p>
            </div>
            <div class="dashboard-card">
                <h3>Total News</h3>
                <p><?php echo number_format($total_news); ?>+</p>
            </div>
            <div class="dashboard-card">
                <h3>Active Users</h3>
                <p><?php echo number_format($total_active_users); ?>+</p>
            </div>
            <div class="dashboard-card">
                <h3>Total Donations</h3>
                <p>₹<?php echo number_format($total_donations); ?>+</p>
            </div>
        </div>
    </div>
  
    
    
   

    <script>
        function toggleNav() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
                x.className += " responsive";
                openNav();
            } else {
                x.className = "topnav";
                closeNav();
            }
        }

        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
    </script>
      <script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</body>
</html>

<?php include 'footer.php'; ?>
<!-- 

CREATE TABLE alumni (
    user_id INT PRIMARY KEY,
    name VARCHAR(255),
    date_of_birth DATE,
    gender ENUM('Male', 'Female', 'Other'),
    college VARCHAR(255),
    work_status VARCHAR(100),
    profile_photo VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(id)
); -->