<?php
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}
include 'connect.php';

// Function to fetch and display existing user data
function fetchUserData($conn) {
    $existing_data = array(); // Initialize an array to hold existing data
    if (isset($_SESSION['email'])) {
        $email = $conn->real_escape_string($_SESSION['email']);
        $query = "SELECT * FROM users WHERE email = '$email'";
        $result = $conn->query($query);
        if ($result && $result->num_rows > 0) {
            $existing_data = $result->fetch_assoc(); // Fetch data once
        }
    }
    return $existing_data;
}

// Function to update user data
function updateUserData($conn) {
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
        // Ensure email is set
        if (isset($_SESSION['email'])) {
            $email = $conn->real_escape_string($_SESSION['email']);
            
            // Fetch and sanitize input data
            $emial = $conn->real_escape_string($_POST['email']);
            $name = $conn->real_escape_string($_POST['name']);
            $dob = $conn->real_escape_string($_POST['date_of_birth']);
            $gender = $conn->real_escape_string($_POST['gender']);
            $college_id = $conn->real_escape_string($_POST['college_id']);
            $contact = $conn->real_escape_string($_POST['contact']);
            $passing_year = $conn->real_escape_string($_POST['passing_year']);
            $work_status = $conn->real_escape_string($_POST['work_status']);
            // $profile_photo = $conn->real_escape_string($_POST['profile_photo']);
            
            // Update query
            $update_query = "UPDATE users SET name='$name', date_of_birth='$dob', gender='$gender', college_id='$college_id', contact='$contact', passing_year='$passing_year', work_status='$work_status' WHERE email='$email'";

            // Execute the query
            if (mysqli_query($conn, $update_query)) {
                // echo "Record updated successfully";
               header("Location:../Student/profile.php");
              
            } else {
                echo "Error updating record: " . mysqli_error($conn);
            }
        }
    }
}

// Call the functions
$existing_data = fetchUserData($conn);
updateUserData($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile - Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <!-- <a href="alumni.php">Alumni</a> -->
            <a href="alumni.php">Alumni</a> 
            <a href="events.php">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="syllabus.php">Syllabus</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="#"  class="active" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>
<div class="main-content">
    <div class="header">
        <h2>Update Profile</h2>
    </div>
    
    <div class="profile-form">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
            <table class="profile-table">
                <tr style="border-bottom: 2px solid black;">
                    <td><h3>Field</h3></td>
                    <td><h3>Data</h3></td>
                    <td><h3>Update</h3></td>
                </tr>
                <tr>
                    <td><label for="email">Email:</label></td>
                    <td><?php echo htmlspecialchars(isset($existing_data['email']) ? $existing_data['email'] : ''); ?></td> 
                    <td><?php echo htmlspecialchars(isset($existing_data['email']) ? $existing_data['email'] : ''); ?></td> 
                </tr>
                <tr>
                    <td><label for="full_name">Full Name:</label></td>
                    <td><?php echo htmlspecialchars(isset($existing_data['name']) ? $existing_data['name'] : ''); ?></td>
                    <td><input type="text" id="full_name" name="name" value="<?php echo htmlspecialchars(isset($existing_data['name']) ? $existing_data['name'] : ''); ?>"></td>
                   
                </tr>
                <tr>
                    <td><label for="dob">Date of Birth:</label></td>
                    <td><?php echo htmlspecialchars(isset($existing_data['date_of_birth']) ? $existing_data['date_of_birth'] : ''); ?></td>
                    <td><input type="date" id="dob" name="date_of_birth" value="<?php echo htmlspecialchars(isset($existing_data['date_of_birth']) ? $existing_data['date_of_birth'] : ''); ?>"></td>
           
                </tr>
                <tr>
                    <td><label for="gender">Gender:</label></td>
                    <td><?php echo htmlspecialchars(isset($existing_data['gender']) ? $existing_data['gender'] : ''); ?></td>
                    <td>
                        <select id="gender" name="gender">
                            
                            <option value="<?php echo htmlspecialchars(isset($existing_data['gender']) ? $existing_data['gender'] : ''); ?>" >Update</option>

                            <option value="male" <?php echo (isset($existing_data['gender']) && $existing_data['gender'] == 'male') ? 'selected' : ''; ?>>Male</option>
                            <option value="female" <?php echo (isset($existing_data['gender']) && $existing_data['gender'] == 'female') ? 'selected' : ''; ?>>Female</option>
                            <option value="other" <?php echo (isset($existing_data['gender']) && $existing_data['gender'] == 'other') ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </td>
                    
                </tr>
               
                <tr>
                    <td><label for="contact">Contact:</label></td>
                    <td><?php echo htmlspecialchars(isset($existing_data['contact']) ? $existing_data['contact'] : ''); ?></td>
                    <td><input type="text" id="contact" name="contact" value="<?php echo htmlspecialchars(isset($existing_data['contact']) ? $existing_data['contact'] : ''); ?>"></td>
                    
                </tr>
                 <tr>
                    <td><label for="college_id">College Id:</label></td>
                    <td><?php echo htmlspecialchars(isset($existing_data['college_id']) ? $existing_data['college_id'] : ''); ?></td>
                    <td><input  id="college_id" name="college_id" value="<?php echo htmlspecialchars(isset($existing_data['college_id']) ? $existing_data['college_id'] : ''); ?>"></td>
                </tr>
                <tr>
                    <td><label for="passing_year">Passing Year:</label></td>
                    <td><?php echo htmlspecialchars(isset($existing_data['passing_year']) ? $existing_data['passing_year'] : ''); ?></td>
                    <td><input type="number" id="passing_year" name="passing_year" value="<?php echo htmlspecialchars(isset($existing_data['passing_year']) ? $existing_data['passing_year'] : ''); ?>"></td>
                  
                </tr>
                <tr>
                    <td><label for="work_status">Work Status:</label></td>
                    <td><?php echo htmlspecialchars(isset($existing_data['work_status']) ? $existing_data['work_status'] : ''); ?></td>
                    <td>
                      
                        <select id="work_status" name="work_status">
                            <option value="<?php echo htmlspecialchars(isset($existing_data['work_status']) ? $existing_data['work_status'] : ''); ?>" >Update</option>

                            <option value="employed" <?php echo (isset($existing_data['work_status']) && $existing_data['work_status'] == 'employed') ? 'selected' : ''; ?>>Employed</option>
                            <option value="unemployed" <?php echo (isset($existing_data['work_status']) && $existing_data['work_status'] == 'unemployed') ? 'selected' : ''; ?>>Unemployed</option>
                            <option value="student" <?php echo (isset($existing_data['work_status']) && $existing_data['work_status'] == 'student') ? 'selected' : ''; ?>>Student</option>
                            <option value="retired" <?php echo (isset($existing_data['work_status']) && $existing_data['work_status'] == 'retired') ? 'selected' : ''; ?>>Retired</option>
                        </select>
                    </td>
                    
                </tr>
                <tr>
                    <td><label for="profile_photo">Profile Photo:</label></td>
                    <td><?php echo htmlspecialchars($existing_data['profile_photo']); ?></td>
                    <td>
                    <input type="file" id="profile_photo" name="profile_photo" value="<?php echo htmlspecialchars($existing_data['profile_photo']); ?>">
                </td>
                    
                   
                </tr>
               
                <tr>
                    <td colspan="3"><input class="btcolor" type="submit" name="update" value="Save Changes" style=" background-color: #4CAF50;
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s;
    float: right;
    margin-top: 10px;"></td>
                </tr>
            </table>
        </form>
    </div>
</div>
<script>
function confirmLogout() {
    if (confirm("Are you sure you want to logout?")) {
        fetch('logout.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=logout'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("You have been successfully logged out.");
                window.location.href = '../home.php'; 
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("An error occurred during logout. Please try again.");
        });
    }
}
</script>
</body>
</html>

<?php include 'footer.php'; ?>