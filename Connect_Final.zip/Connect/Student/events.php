<?php
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}
include 'connect.php'; // Ensure this file contains your database connection

// Function to fetch event details
function getEvent($id) {
    global $conn; // Use the global connection variable
    $stmt = $conn->prepare("SELECT id, title, start_date, end_date, details FROM events WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events List</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
   
<div class="topnav" id="myTopnav">
        <div class="logo">
            <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
            <span style="vertical-align: middle;">CE Connect</span>
        </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <!-- <a href="alumni.php">Alumni</a> -->
            <a href="alumni.php">Alumni</a>
            <a href="events.php" class="active">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="syllabus.php">Syllabus</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php">Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
           
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <h2>Upcoming Events</h2>
        </div>


        <!-- Events Display -->
        <div class="events-list">
            <!-- <h3></h3> -->
            <table class="events-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Title</th>
                        <th>Details</th>
             
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'connect.php'; // Make sure this file contains your database connection

                    // Fetch the required data from the events table
                    $sql = "SELECT id, start_date, end_date, title, details FROM events ORDER BY start_date"; // Updated SQL query
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["id"] . "</td>";
                            echo "<td>" . $row["start_date"] . "</td>";
                            echo "<td>" . $row["end_date"] . "</td>"; // Added end_date
                            echo "<td>" . $row["title"] . "</td>";
                            echo "<td style='max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;'>" . $row["details"] . "</td>";
                           
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No events found</td></tr>"; // Updated colspan
                    }
                    ?>
                   
                </tbody>
            </table>
        </div>
    </div>
    
    <?php
    $conn->close();
    ?>

    <script>

        function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                fetch('logout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=logout'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert("You have been successfully logged out.");
                        window.location.href = '../home.php'; 
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert("An error occurred during logout. Please try again.");
                });
            }
        }
    </script>

</body>
</html>

<?php include 'footer.php'; ?>