<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
// Assume you have a function to get user data from the database
// $user_data = getUserData($user_id);

// Placeholder user data (replace with actual data from database)
$user_data = [
    'full_name' => 'John Doe',
    'dob' => '2004-01-01',
    'email' => 'johndoe@example.com',
    'contact' => '987654321',
    'gender' => 'male',
    'passing_year' => '2025',
    'college' => 'college1',
    'work_status' => 'student'
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile - Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="sidebar">
    <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="profile.php" class="active">Edit Profile</a></li>
        <li><a href="alumni.php">Alumni Member</a></li>
        <li><a href="events.php">Events List</a></li>
        <li><a href="jobs.php">Job Post</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="help.php">Help</a></li>
        <li><a href="#" onclick="confirmLogout()">Logout</a></li>
    </ul>
</div>
<div class="main-content">
    <div class="header">
        <h2>Edit Profile</h2>
    </div>
    
    <div class="profile-form">
        <form action="update_profile.php" method="post" enctype="multipart/form-data">
            <div class="form-grid">
                <div class="d1">
                    <label for="full_name">Full Name:</label>
                    <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user_data['full_name']); ?>"><br>

                    <label for="dob">Date of Birth:</label>
                    <input type="date" id="dob" name="dob" value="<?php echo htmlspecialchars($user_data['dob']); ?>"><br>
                    
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>"><br>

                    <label for="contact">Contact:</label>
                    <input type="text" id="contact" name="contact" value="<?php echo htmlspecialchars($user_data['contact']); ?>"><br>

                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password"><br>
                </div>
                <div class="d2">
                    <label for="gender">Gender:</label>
                    <select id="gender" name="gender">
                        <option value="male" <?php echo $user_data['gender'] == 'male' ? 'selected' : ''; ?>>Male</option>
                        <option value="female" <?php echo $user_data['gender'] == 'female' ? 'selected' : ''; ?>>Female</option>
                        <option value="other" <?php echo $user_data['gender'] == 'other' ? 'selected' : ''; ?>>Other</option>
                    </select><br>

                    <label for="passing_year">Passing Year:</label>
                    <input type="number" id="passing_year" name="passing_year" value="<?php echo htmlspecialchars($user_data['passing_year']); ?>"><br>

                    <label for="profile_photo">Profile Photo:</label>
                    <input type="file" id="profile_photo" name="profile_photo"><br>

                    <label for="college">College:</label>
                    <select id="college" name="college">
                        <option value="college1" <?php echo $user_data['college'] == 'college1' ? 'selected' : ''; ?>>College 1</option>
                        <option value="college2" <?php echo $user_data['college'] == 'college2' ? 'selected' : ''; ?>>College 2</option>
                        <option value="college3" <?php echo $user_data['college'] == 'college3' ? 'selected' : ''; ?>>College 3</option>
                    </select><br>

                    <label for="work_status">Work Status:</label>
                    <select id="work_status" name="work_status">
                        <option value="employed" <?php echo $user_data['work_status'] == 'employed' ? 'selected' : ''; ?>>Employed</option>
                        <option value="unemployed" <?php echo $user_data['work_status'] == 'unemployed' ? 'selected' : ''; ?>>Unemployed</option>
                        <option value="student" <?php echo $user_data['work_status'] == 'student' ? 'selected' : ''; ?>>Student</option>
                        <option value="retired" <?php echo $user_data['work_status'] == 'retired' ? 'selected' : ''; ?>>Retired</option>
                    </select><br>
                </div>
            </div>
            <input type="submit" value="Save Changes">
        </form>
    </div>
</div>
<script>
function confirmLogout() {
    if (confirm("Are you sure you want to logout?")) {
        fetch('logout.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=logout'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("You have been successfully logged out.");
                window.location.href = 'login.php'; 
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("An error occurred during logout. Please try again.");
        });
    }
}
</script>
</body>
</html>
