<?php
session_start();
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['update_id']);
    $title = $_POST['update_title'];
    $start_date = $_POST['update_date'];
    $end_date = $_POST['update_end_date'];
    $details = $_POST['update_detail'];

    $stmt = $conn->prepare("UPDATE events SET title = ?, start_date = ?, end_date = ?, details = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $title, $start_date, $end_date, $details, $id);

    if ($stmt->execute()) {
        echo json_encode(array('success' => true));
    } else {
        echo json_encode(array('success' => false, 'error' => 'Failed to update event.'));
    }

    $stmt->close();
}
$conn->close();
?>