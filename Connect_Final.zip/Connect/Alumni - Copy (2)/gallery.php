<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css"> 
    <style>
        .gallery-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); /* Responsive grid */
            gap: 20px; /* Space between images */
            padding: 20px;
        }
        .gallery-container img {
            width: 100%;
            height: auto;
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Image shadow */
        }
    </style>
</head>
<body>
<div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="gallery.php" class="active">Gallery</a>
            <a href="help.php">Help</a>
            <a href="#" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>

<div class="main-content">
    <div class="header">
        <h2>Gallery</h2>
    </div>
    <div>
        <h3>Alumni photos</h3>
    </div>
    <div class="gallery-container">
        <img src="image/1.JPEG" alt="Alumni 1">
        <img src="image/2.JPEG" alt="Alumni 2">
        <img src="image/8.JPEG" alt="Alumni 3">
        <img src="image/4.JPEG" alt="Alumni 4">
        <img src="image/5.JPEG" alt="Alumni 5">
        <img src="image/6.JPEG" alt="Alumni 6">
        <img src="image/7.JPEG" alt="Alumni 7">
        <img src="image/3.JPEG" alt="Alumni 8">
        <img src="image/9.JPEG" alt="Alumni 9">
        <img src="image/10.JPEG" alt="Alumni 10">
    </div>
</div>

<script>
    function toggleNav() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
            x.className += " responsive";
            openNav();
        } else {
            x.className = "topnav";
            closeNav();
        }
    }

    function openNav() {
        document.getElementById("mySidenav").style.width = "250px";
    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
    }

    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = 'login.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
</script>

</body>
</html>
