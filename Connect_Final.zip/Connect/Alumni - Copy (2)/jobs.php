<?php
session_start();
include 'connect.php';

// Check if the form is submitted for adding a job post
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['delete_id'])) {
    // Sanitize and validate input data
    $date = $conn->real_escape_string($_POST['date']);
    $company_name = $conn->real_escape_string($_POST['company_name']);
    $job_type = $conn->real_escape_string($_POST['type']);
    $requirements = $conn->real_escape_string($_POST['requirements']);

    // Prepare SQL statement
    $sql = "INSERT INTO job_posts (date, company_name, job_type, requirements) VALUES (?, ?, ?, ?)";
    
    // Create a prepared statement
    $stmt = $conn->prepare($sql);
    
    // Bind parameters to the prepared statement
    $stmt->bind_param("ssss", $date, $company_name, $job_type, $requirements);
    
    // Execute the statement
    if ($stmt->execute()) {
        $message = "Job post added successfully!";
        // Redirect to the same page to prevent resubmission
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        $message = "Error: " . $stmt->error;
    }
    
    // Close the statement
    $stmt->close();
}

// Check if a delete request is made
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $delete_id = $conn->real_escape_string($_POST['delete_id']);
    $delete_sql = "DELETE FROM job_posts WHERE id = ?";
    
    // Prepare and execute the delete statement
    if ($delete_stmt = $conn->prepare($delete_sql)) {
        $delete_stmt->bind_param("i", $delete_id);
        
        if ($delete_stmt->execute()) {
            echo json_encode(array('success' => true));
        } else {
            echo json_encode(array('success' => false, 'error' => $delete_stmt->error));
        }
        $delete_stmt->close();
    } else {
        echo json_encode(array('success' => false, 'error' => 'Prepare failed: ' . $conn->error));
    }
    exit; // Exit to prevent further processing
}

// Fetch job posts from the database
$sql = "SELECT * FROM job_posts ORDER BY date DESC";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Posts - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php" class="active">Job Post</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="#" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>

    <div class="main-content">
        <?php
        if (isset($message)) {
            echo '<div class="message">' . $message . '</div>';
        }
        ?>
        
        <div class="header">
            <h2>Job Posts</h2>
        </div>

        <div class="add-job">
            <h3>Add New Job Post</h3>
            <form id="job-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <table class="form-table" >
                    <tr>
                        <td>
                            <label for="date">Date:</label>
                            <input type="date" id="date" name="date" required>
                        </td>
                        <td>
                            <label for="company_name">Company Name:</label>
                            <input type="text" id="company_name" name="company_name" required>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="type">Job Type:</label>
                            <select id="type" name="type" required>
                                <option value="full_time">Full Time</option>
                                <option value="part_time">Part Time</option>
                                <option value="internship">Internship</option>
                            </select>
                        </td>
                        <td>
                            <label for="requirements">Requirements:</label>
                            <textarea id="requirements" name="requirements" rows="4" required></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <button type="submit" id="insert-btn">Add Job Post</button>
                        </td>
                    </tr>
                </table>
            </form>
        </div>

        <div class="jobs-list">
            <h3>Existing Job Posts</h3>
            <table class="jobs-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Company Name</th>
                        <th>Job Type</th>
                        <th>Requirements</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["date"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["company_name"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["job_type"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["requirements"]) . "</td>";
                            echo "<td><button class='delete-btn' data-uid='" . htmlspecialchars($row["id"]) . "'>Delete</button></td>"; // Delete button
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No job posts found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php
    $conn->close();
    ?>

    <script>
        // Handle insert button click
        document.getElementById('insert-btn').addEventListener('click', function(event) {
            const form = document.getElementById('job-form');
            if (!form.checkValidity()) {
                event.preventDefault(); // Prevent form submission if invalid
                alert("Please fill in all required fields.");
            }
        });

        // Handle delete button click
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function() {
                const deleteId = this.getAttribute('data-uid');
                if (confirm("Are you sure you want to delete this job post?")) {
                    fetch('jobs.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'delete_id=' + deleteId
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert("Job post deleted successfully.");
                            location.reload(); // Reload the page to see the changes
                        } else {
                            alert("Error: " + data.error);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert("An error occurred while deleting the job post. Please try again.");
                    });
                }
            });
        });
    </script>

    <script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = 'login.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</body>
</html>