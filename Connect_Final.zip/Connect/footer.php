<head>
    <link href="styles/header_footer.css" rel="stylesheet">
    <link href="styles/common.css" rel="stylesheet">
</head>


<footer class="footer">
    <div class="footer-content">
        <div class="footer-section footer-about">
            <h3>About Us</h3>
            <p>We serve as a bridge between students, faculty, and alumni, fostering a collaborative environment for learning and growth.</p>
        </div>
        
        <div class="footer-section footer-links">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="aboutus.php">About Us</a></li>
                <li><a href="donation.php">Donation</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </div>

        <div class="footer-section footer-contact">
            <h3>Contact Us</h3>
            <p>E-mail:</p>
            <p><a href="mailto:d23ce186@charusat.edu.in">d23ce172@charusat.edu.in</a></p>
            <p><a href="mailto:d23ce186@charusat.edu.in">d23ce186@charusat.edu.in</a></p>
            <p><a href="tel:+910000000000">Phone: +91 98765 43210</a></p>
        </div>

        <div class="footer-section footer-social">
            <h3>Follow Us</h3>
            <ul>
                <li><a href="https://www.facebook.com/ce.cspit.charusat" target="_blank">Facebook</a></li>
                <li><a href="https://x.com/thecharusat" target="_blank">Twitter</a></li>
                <li><a href="https://www.linkedin.com/in/ce-cspit-charusat/" target="_blank">LinkedIn</a></li>
                <li><a href="https://www.instagram.com/ce_cspit_charusat?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" target="_blank">Instagram</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2024 CE Connect. All rights reserved.</p>
    </div>
</footer>
