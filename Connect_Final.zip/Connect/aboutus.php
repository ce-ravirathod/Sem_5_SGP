<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CE Connect - Contact Us</title>
    <link href="styles/common.css" rel="stylesheet">
    <link href="styles/aboutus.css" rel="stylesheet">
    <link href="styles/header_footer.css" rel="stylesheet">
    <script src="js/main.js"></script>
</head>
<body>
    <nav class="header-topnav">
        <div class="header-logo">
            <img src="https://d2lk14jtvqry1q.cloudfront.net/media/large_Charotar_University_of_Science_and_Technology_CHARUSAT_Anand_fdce544903_1202e15c5f.png" alt="CHARUSAT Logo">
            <span>CE Connect</span>
        </div>
        
        <div class="header-menu-icon" onclick="toggleMenu()">&#9776;</div>
        <div class="header-topnav-right">
            <a href="home.php">Home</a>
            <a href="aboutus.php" class="active">About Us</a>
            <a href="donation.php">Donation</a>
            <a href="login.php">Login</a>
        </div>
    </nav>

    <main class="contact-us-container">
        <section class="hero-section">
            <h1>CONTACT US</h1>
            <p>We're here to help. Reach out to us for any questions or support you need.</p>
        </section>

        <section class="association">
            <h2>Alumni Association</h2>
            <div class="board-members">
                <div class="board-member">
                    <img src="images/board-member-1.jpeg" alt="Board Member 1">
                    <h3>John Doe</h3>
                    <p>President</p>
                </div>
                <div class="board-member">
                    <img src="images/board-member-2.jpeg" alt="Board Member 2">
                    <h3>Jane Smith</h3>
                    <p>Vice President</p>
                </div>
            </div>
            <div class="info-boxes">
                <div class="info-box">
                    <h3>How to help?</h3>
                    <p>Support our alumni community through mentorship, donations, or volunteering. Your contribution makes a difference.</p>
                    <a href="#" class="learn-more-btn">Learn More</a>
                    <!-- in this page pop content -->
                </div>
                <div class="info-box">
                    <h3>Our mission</h3>
                    <p>We strive to foster lifelong connections among alumni, support their professional growth, and strengthen the CE community.</p>
                    <a href="#" class="learn-more-btn">Learn More</a>
                </div>
                <div class="info-box">
                    <h3>Contact Us</h3>
                    <p><strong>Location:</strong> Charusat University, Changa, Petlad, Anand, Gujarat - 388421</p>
                    <p><strong>Office Hours:</strong> Monday-Friday, 9:00 AM - 6:00 PM</p>
                    <p><strong>Email:</strong> contact@ceconnect.edu</p>
                    <p><strong>Phone:</strong>+1 (234) 567-8910</p>
                </div>
            </div>
        </section>

        <section class="contact-form">
            <h2>Get in Touch</h2>
            <form>
                <input type="text" placeholder="Name" required>
                <input type="email" placeholder="Email" required>
                <input type="tel" placeholder="Phone" required>
                <textarea placeholder="Message" required></textarea>
                <button type="submit">Send Message</button>
            </form>
            <!-- for this save data into exel sheet... -->
             <!-- face version problem -->
        </section>
    </main>
    
    <?php include('footer.php'); ?>
</body>
</html>
