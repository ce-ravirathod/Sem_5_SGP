<?php
// Include the database connection file
include('connect.php');

// Fetch events and stories from the database (limit to 3 for each)
$sql_events = "SELECT id, title, details, start_date FROM events LIMIT 3";
$result_events = $conn->query($sql_events);

$sql_stories = "SELECT date, title, description FROM stories LIMIT 3";
$result_stories = $conn->query($sql_stories);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CE Connect - Home</title>
    <link href="styles/header_footer.css" rel="stylesheet">
    <link href="styles/common.css" rel="stylesheet">
    <link href="styles/home.css" rel="stylesheet"> 
    <script src="js/main.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="header-topnav">
        <div class="header-logo">
            <img src="images\logo.png" alt="CHARUSAT Logo">
            <span>CE Connect</span>
        </div>
        <div class="header-menu-icon" onclick="toggleMenu()">&#9776;</div>
        <div class="header-topnav-right">
            <a href="home.php" class="active">Home</a>
            <a href="aboutus.php">About Us</a>
            <a href="donation.php">Donation</a>
            <a  href="login.php">Login</a>
        </div>
    </nav>

    <section class="image-showcase">
            <div class="showcase-container">
                <div class="showcase-slider">
                    <div class="hero showcase-slide">
                        <div class="hero-container">
                            <h1>Welcome to CE Connect</h1>
                            <p>"An innovative alumni System, Bridging Students, Faculty, and Alumni for Academic and Career Success"</p>
                            <a href="login.php" class="btn btn-primary">Join Our Community</a>
                        </div>
                    </div>
                    <img src="images/showcase1.jpeg" alt="Showcase Image 1" class="showcase-image">
                    <img src="images/showcase2.jpg" alt="Showcase Image 2" class="showcase-image">
                    <img src="images/showcase4.jpeg" alt="Showcase Image 3" class="showcase-image">
                   
                    <div class="showcase-placeholder">Add Image Here</div>
                </div>
                <button class="showcase-prev">&lt;</button>
                <button class="showcase-next">&gt;</button>
            </div>
    </section>    
<main>
    
        <section class="news-achievements">
            <div class="news-achievements-container">
                <div class="news">
                    <h2 class="section-title">News <a href="view_all.php" class="view-all">View All</a></h2>
                    <div class="news-item">
                        <p class="news-date">24 Oct 2023</p>
                        <p class="news-title">24TH AGM OF THE CSPIT CE ALUMNI ASSOCIATION</p>
                        <p class="news-location">CSPIT, Changa</p>
                    </div>
                    <!-- More news items -->
                </div>
                <div class="achievements">
                    <h2 class="section-title">Achievements <a href="achievement.php" class="view-all">View All</a></h2>
                    <div class="achievement-item">
                        <p class="achievement-date">02 Jul 2023</p>
                        <p class="achievement-quote">CSPIT CE Alumni Association Felicitates the University for Outstanding Achievements</p>
                        <p class="achievement-author">CSPIT CE ALUMNI</p>
                    </div>
                    <!-- More achievement items -->
                </div>
            </div>
        </section>

        <section class="alumni-activities">
            <div class="alumni-activities-container">
                <h2 class="section-title">Current Activities By Association</h2>
                <div class="alumni-activities-item">
                    <ul class="alumni-activities-list">
                        <li>Organising seminars and workshops to prepare leaders for the new millennium</li>
                        <li>Providing financial support in the form of merit-cum-means scholarships</li>
                        <li>Providing travel assistance to students for participating in academic activities</li>
                        <li>Awarding prizes to rank holding students</li>
                        <li>Assisting in arranging campus interviews, placements and industrial training</li>
                        <li>Maintaining a database of ex-students</li>
                        <li>A new year gathering is arranged every year for local members on 26th January, after the flag hoisting ceremony. Other trips with family are also organised</li>
                    </ul>
                </div>
            </div>
        </section>

        <section class="event-stories">
            <div class="event-stories-container">
                <div class="event">
                    <h2 class="section-title">Events <a href="event.php" class="view-all">View All</a></h2>
                    <div class="event-item">
                        <?php if ($result_events->num_rows > 0): ?>
                            <?php while($row = $result_events->fetch_assoc()): ?>
                                <div class="event-content">
                                    <p class="event-date"><?php echo $row['start_date']; ?></p>
                                    <p class="event-title"><?php echo $row['title']; ?></p>
                                    <p class="event-location"><?php echo $row['details']; ?></p>
                                </div>
                                <hr class="story-separator">
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p>No events found.</p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="stories">
                    <h2 class="section-title">Alumni Stories <a href="storie.php" class="view-all">View All</a></h2>
                    <div class="event-item">
                        <?php if ($result_stories->num_rows > 0): ?>
                            <?php while($row = $result_stories->fetch_assoc()): ?>
                                <div class="event-content">
                                    <p class="event-date"><?php echo $row['date']; ?></p>
                                    <p class="event-title"><?php echo $row['title']; ?></p>
                                    <p class="event-location"><?php echo $row['description']; ?></p>
                                </div>
                                <hr class="story-separator">
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p>No stories found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>

        <section class="prominent-alumni">
            <div class="prominent-alumni-container">
                <h2 class="section-title">Prominent Alumni</h2>
                <div class="alumni-grid">
                    <div class="alumni-card">
                        <img src="images/alumni1.jpg" alt="Ravi Rathod" class="alumni-photo">
                        <h3>Anil Rathod</h3>
                        <p>CEO of TechInnovate, revolutionizing AI-driven solutions in healthcare.</p>
                    </div>
                    <div class="alumni-card">
                        <img src="images/alumni2.jpg" alt="Priya Patel" class="alumni-photo">
                        <h3>Priya Patel</h3>
                        <p>Lead Data Scientist at Google, spearheading machine learning projects.</p>
                    </div>
                    <div class="alumni-card">
                        <img src="images/alumni3.jpeg" alt="Amit Shah" class="alumni-photo">
                        <h3>Amit Shah</h3>
                        <p>Founder of EcoTech, developing sustainable energy solutions globally.</p>
                    </div>
                    <div class="alumni-card">
                        <img src="images/alumni4.jpg" alt="Neha Desai" class="alumni-photo">
                        <h3>Neha Desai</h3>
                        <p>CTO of FinTech startup, innovating in blockchain and cryptocurrency.</p>
                    </div>
                    <div class="alumni-card">
                        <img src="images/alumni5.jpg" alt="Vikram Mehta" class="alumni-photo">
                        <h3>Vikram Mehta</h3>
                        <p>Senior Software Architect at Microsoft, leading cloud computing initiatives.</p>
                    </div>
                    <div class="alumni-card">
                        <img src="images/alumni6.jpg" alt="Anita Sharma" class="alumni-photo">
                        <h3>Anish Sharma</h3>
                        <p>Cybersecurity expert and author, advising Fortune 500 companies on digital safety.</p>
                    </div>
                </div>
            </div>
        </section>
        
        

    </main>
    <?php include('footer.php') ?>


</body>
</html>