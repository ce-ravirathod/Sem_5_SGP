<?php
session_start();
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ce";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name']; // New field for name
    $email = $_POST['email'];
    
    // Check if the email already exists
    $checkEmailSql = "SELECT email FROM users WHERE email = ?";
    $checkStmt = $conn->prepare($checkEmailSql);
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    
    // Bind the result
    $checkStmt->bind_result($existingEmail);
    $checkStmt->store_result(); // Store the result to check the number of rows
    
    if ($checkStmt->num_rows > 0) {
        echo "<script>alert('Email already registered!');</script>"; // New message for duplicate email
    } else {
        if (function_exists('password_hash')) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        } else {
            $password = hash('sha256', $_POST['password']);
        }
        $college_id = !empty($_POST['college_id']) ? $_POST['college_id'] : null;
        $contact = $_POST['contact'];
        $passing_year = $_POST['passing_year'];
        $user_type = $_POST['user_type'];
        
        $sql = "INSERT INTO users (name, email, password, college_id, contact, passing_year, user_type) 
                VALUES (?, ?, ?, ?, ?, ?, ?)"; // Updated SQL query
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssss", $name, $email, $password, $college_id, $contact, $passing_year, $user_type);
        
        if ($stmt->execute()) {
            echo "<script>alert('Registration successful!'); window.location.href='login.php';</script>"; // Redirect to login page after success
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }
        
        $stmt->close();
    }
    
    $checkStmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHARUSAT - Register</title>
    <link rel="stylesheet" href="login.css">
    <style>
        .required::after { content: " *"; color: red; }
    </style>
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <div class="logo-circle">
                <img src="images/University_Hero.png" alt="CHARUSAT Logo">
            </div>
        </div>
        <div class="right-panel">
            <div class="register-form">
                <h3>Create Your Alumni Account</h3>
                <form method="POST" action="register.php" enctype="multipart/form-data">
                    <div class="form-column">
                        <div class="form-field">
                            <label for="name" class="required">Name</label> <!-- New Name field -->
                            <input type="text" id="name" name="name" required>
                        </div>
                        <div class="form-field">
                            <label for="email" class="required">Email</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="form-field">
                            <label for="password" class="required">Password</label>
                            <input type="password" id="password" name="password" required>
                        </div>
                        <!-- <div class="form-field">
                            <label for="college_id">College ID (UID)</label>
                            <input type="text" id="college_id" name="college_id" placeholder="22CE001">
                        </div> -->
                        <div class="form-field">
                            <label for="contact" class="required">Contact Number</label>
                            <input type="text" id="contact" name="contact" required>
                        </div>
                        <div class="form-field">
                            <label for="passing-year" class="required">Passing Year</label>
                            <select id="passing-year" name="passing_year" required>
                                <option value="" disabled selected>Select your passing year</option>
                                <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                        const passingYearSelect = document.getElementById('passing-year');
                                        const currentYear = new Date().getFullYear();
                                        const startYear = 1990;
                                        for (let year = currentYear; year >= startYear; year--) {
                                            const option = document.createElement('option');
                                            option.value = year;
                                            option.textContent = year;
                                            passingYearSelect.appendChild(option);
                                        }
                                    });
                                </script>
                            </select>
                        </div>
                        <div class="form-field">
                            <label for="user-type" class="required">User Type</label>
                            <select id="user-type" name="user_type" required>
                                <option value="" disabled selected>Select user type</option>
                                <option value="student">Student</option>
                                <option value="alumni">Alumni</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit">Sign Up</button>
                </form>
                <div class="back-to-login">
                    Already have an account? <a href="login.php">Log In</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>