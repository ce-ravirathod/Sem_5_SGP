<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CE Connect - Achievements</title>
    <link href="styles/common.css" rel="stylesheet">
    <link href="styles/home.css" rel="stylesheet">
    <link href="styles/view_all.css" rel="stylesheet">
    <link href="styles/header_footer.css" rel="stylesheet">
    <script src="js/main.js"></script>
</head>
<body>
    <nav class="header-topnav">
        <div class="header-logo">
            <img src="https://d2lk14jtvqry1q.cloudfront.net/media/large_Charotar_University_of_Science_and_Technology_CHARUSAT_Anand_fdce544903_1202e15c5f.png" alt="CHARUSAT Logo">
            <span>CE Connect</span>
        </div>
        <div class="header-menu-icon" onclick="toggleMenu()">&#9776;</div>
        <div class="header-topnav-right">
            <a href="home.php">Home</a>
            <a href="aboutus.php">About Us</a>
            <a href="donation.php">Donation</a>
            <a href="Admin/login.php">Login</a>
        </div>
    </nav>

    <main class="view-all-container">
        <a href="home.php" class="back-button"></a>
        <h1 class="view-all-title">Achievements</h1>
        
        <div class="view-all-grid">
            <!-- Static content for achievements -->
            <div class="view-all-item">
                <div class="item-type">Achievement</div>
                <h2 class="item-title">Alumni Wins Prestigious Award</h2>
                <p class="item-subtitle">Recognition for groundbreaking research</p>
                <p class="item-date">2023-06-02</p>
                <a href="#" class="item-read-more">Read More</a>
            </div>
            <div class="view-all-item">
                <div class="item-type">Achievement</div>
                <h2 class="item-title">Student Team Wins Hackathon</h2>
                <p class="item-subtitle">Innovative solution earns top honors</p>
                <p class="item-date">2023-05-20</p>
                <a href="#" class="item-read-more">Read More</a>
            </div>
            <div class="view-all-item">
                <div class="item-type">Achievement</div>
                <h2 class="item-title">Faculty Publishes Groundbreaking Paper</h2>
                <p class="item-subtitle">Research featured in top international journal</p>
                <p class="item-date">2023-07-15</p>
                <a href="#" class="item-read-more">Read More</a>
            </div>
            <div class="view-all-item">
                <div class="item-type">Achievement</div>
                <h2 class="item-title">Department Receives Accreditation</h2>
                <p class="item-subtitle">Recognition of academic excellence</p>
                <p class="item-date">2023-04-30</p>
                <a href="#" class="item-read-more">Read More</a>
            </div>
        </div>
    </main>

    <div id="popupOverlay" class="popup-overlay">
        <div class="popup-content">
            <span class="close-popup">&times;</span>
            <h2 id="popupTitle"></h2>
            <p id="popupSubtitle"></p>
            <p id="popupDate"></p>
            <div id="popupContent"></div>
        </div>
    </div>
    
    <?php include('footer.php'); ?>
</body>
</html>
