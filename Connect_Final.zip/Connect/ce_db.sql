-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Oct 11, 2024 at 08:04 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `ce`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `events`
-- 

CREATE TABLE `events` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(50) NOT NULL,
  `details` text,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

-- 
-- Dumping data for table `events`
-- 

INSERT INTO `events` (`id`, `title`, `details`, `start_date`, `end_date`) VALUES 
(1, 'Alumni Meetup', 'Annual meetup of all alumni at the university campus. Join us for networking, workshops, and a trip down memory lane.', '2024-10-08', '2024-10-09'),
(2, 'Career Fair', 'Connect with potential employers and explore job opportunities. Bring your resume and be ready to impress!', '2024-10-10', '2024-10-17'),
(5, 'Spring Reunion', 'Welcome back to campus! Join fellow alumni for a day of activities, campus tours, and catching up with old friends.', '2024-10-11', '2024-10-12'),
(7, 'Summer Networking Mixer', 'Beat the heat with cool connections! Join us for an evening of networking and refreshments with fellow alumni.', '2024-10-06', '2024-10-07'),
(15, 'Navratri', 'Garba is going...                  ', '2024-10-03', '2024-10-12'),
(16, 'qqw', '1223', '2024-10-09', '2024-10-12'),
(18, 'qwe', 'asdfghjkl', '2024-10-13', '2024-10-15'),
(19, 'Homecoming Weekend', 'Celebrate homecoming with a parade, games, and alumni gatherings!', '2024-10-15', '2024-10-16'),
(20, 'Fall Fest', 'Join us for food, music, and fun activities on the quad!', '2024-10-20', '2024-10-20'),
(21, 'Campus Sustainability Day', 'Workshops and panels on sustainability practices on campus.', '2024-10-22', '2024-10-22'),
(22, 'Halloween Costume Contest', 'Dress up and participate in our annual costume competition!', '2024-10-25', '2024-10-25'),
(23, 'Diwali Celebration', 'Experience the festival of lights with cultural performances and food!', '2024-10-28', '2024-10-30'),
(24, 'Guest Speaker Series', 'Join us for an inspiring talk by a distinguished alumnus!', '2024-11-01', '2024-11-01'),
(25, 'Research Symposium', 'Showcase of student research projects and innovative ideas.', '2024-11-05', '2024-11-05'),
(26, 'Winter Sports Fair', 'Learn about winter sports clubs and activities on campus.', '2024-11-10', '2024-11-10'),
(27, 'Thanksgiving Potluck', 'Bring a dish to share and enjoy a meal with the campus community!', '2024-11-15', '2024-11-15'),
(28, 'Art Exhibition Opening', 'Opening night for student art exhibition—come support your peers!', '2024-11-20', '2024-11-20'),
(29, 'Finals Prep Workshop', 'Tips and strategies to ace your finals—open to all students!', '2024-11-25', '2024-11-25'),
(30, 'Winter Wonderland', 'Enjoy festive decorations, activities, and holiday spirit on campus!', '2024-12-01', '2024-12-01'),
(31, 'Community Service Day', 'Volunteer for various local organizations and give back!', '2024-12-05', '2024-12-05'),
(32, 'Holiday Talent Show', 'Showcase your talent and enjoy performances from fellow students!', '2024-12-10', '2024-12-10'),
(33, 'End-of-Semester Bash', 'Celebrate the end of the semester with food, music, and fun!', '2024-12-15', '2024-12-15');

-- --------------------------------------------------------

-- 
-- Table structure for table `job_posts`
-- 

CREATE TABLE `job_posts` (
  `id` int(11) NOT NULL auto_increment,
  `date` date NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `job_type` enum('Full Time','Part Time','Internship') NOT NULL,
  `requirements` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

-- 
-- Dumping data for table `job_posts`
-- 

INSERT INTO `job_posts` (`id`, `date`, `company_name`, `job_type`, `requirements`) VALUES 
(3, '2024-06-11', 'Tech Innovators', 'Internship', 'Looking for enthusiastic computer science students for summer internship'),
(4, '2024-06-12', 'Global Solutions', 'Full Time', 'Senior project manager needed for our IT department'),
(8, '2023-10-05', 'Green Energy Solutions', 'Full Time', 'Experience in renewable energy projects, strong communication skills.'),
(9, '2023-10-10', 'Global Marketing Agency', 'Internship', 'Currently pursuing a degree in Marketing or related field, excellent writing skills.'),
(10, '2023-10-15', 'HealthCare Plus', 'Part Time', 'Registered Nurse with at least 2 years of experience, strong patient care skills.'),
(11, '2023-10-20', 'Finance Corp', 'Part Time', 'Degree in Finance or Accounting, proficiency in Excel and financial modeling.'),
(30, '2024-10-09', 'abcd11', 'Full Time', '12 devloper 12 employees '),
(32, '2024-10-11', 'Divine Infosys', 'Internship', '42 developer '),
(34, '2024-10-12', 'Divine Infosys111', 'Internship', '34 student requests '),
(35, '2024-10-13', 'qwe11', 'Part Time', '122'),
(36, '2024-10-13', 'Infosys', 'Part Time', '123 dev'),
(37, '2024-10-13', 'Tech Solutions Inc.', 'Part Time', 'Flexible hours, must be a team player.'),
(38, '2024-10-14', 'Innovative Designs', 'Internship', 'Seeking creative minds for design internship.'),
(39, '2024-10-15', 'Future Tech Corp.', 'Full Time', 'Experience in software development, team collaboration skills required.'),
(40, '2024-10-16', 'Eco-Friendly Enterprises', 'Part Time', 'Passion for sustainability, strong communication skills.'),
(41, '2024-10-17', 'Health Innovations', 'Internship', 'Must be pursuing a degree in Health Sciences or related field.'),
(42, '2024-10-18', 'Global Finance Ltd.', 'Full Time', 'Degree in Finance, strong analytical skills required.'),
(43, '2024-10-19', 'Digital Marketing Agency', 'Internship', 'Currently pursuing a degree in Marketing or related field.'),
(44, '2024-10-20', 'Consulting Services Group', 'Part Time', 'Excellent organizational skills, customer service experience preferred.'),
(45, '2024-10-21', 'Creative Media House', 'Full Time', 'Experience in content creation and social media management.'),
(46, '2024-10-22', 'Data Analytics Corp.', 'Internship', 'Pursuing a degree in Data Science or Statistics, strong analytical skills.'),
(47, '2024-10-23', 'Global Tech Solutions', 'Part Time', 'Experience in tech support, excellent communication skills.'),
(48, '2024-10-24', 'Web Development Agency', 'Full Time', 'Proficient in HTML, CSS, and JavaScript, portfolio required.'),
(49, '2024-10-25', 'Logistics Services', 'Internship', 'Seeking logistics or supply chain students for summer internship.'),
(50, '2024-10-26', 'Retail Solutions', 'Part Time', 'Strong customer service skills, flexible schedule preferred.'),
(51, '2024-10-27', 'Finance Experts', 'Full Time', 'Experience in financial analysis, degree in Finance or related field required.');

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) default NULL,
  `date_of_birth` date default NULL,
  `gender` enum('Male','Female','Other') default NULL,
  `college_id` varchar(255) default NULL,
  `contact` varchar(15) NOT NULL,
  `passing_year` year(4) NOT NULL,
  `work_status` enum('Unemployed','Employed','Student','Retired') default NULL,
  `profile_photo` varchar(255) default NULL,
  `user_type` enum('student','alumni','admin') NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `unique_email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` (`id`, `email`, `password`, `name`, `date_of_birth`, `gender`, `college_id`, `contact`, `passing_year`, `work_status`, `profile_photo`, `user_type`) VALUES 
(1, 'ravi.rathod772001@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Ravi', '2004-12-09', 'Male', 'Not for Admin', '9313573610', 2021, 'Unemployed', NULL, 'admin'),
(3, 'mike.johnson@example.com', 'mikepass', 'Mike Johnson', '1990-04-12', 'Male', 'D19CE123', '9876543210', 2012, 'Employed', 'mike_profile.jpg', 'alumni'),
(4, 'sara.connor@example.com', 'sarapass', 'Sara Connor', '1995-07-22', 'Female', NULL, '8765432109', 2016, 'Unemployed', 'sara_profile.jpg', 'student'),
(5, 'tom.hanks@example.com', 'tomhanks123', 'Tom Hanks', '1988-11-30', 'Male', '18CE145', '7654321098', 2010, 'Employed', 'tom_profile.jpg', 'alumni'),
(6, 'lisa.white@example.com', 'lisapass', 'Lisa White', '1992-09-15', 'Female', NULL, '6543210987', 2014, 'Student', 'lisa_profile.jpg', 'student'),
(8, 'john.doe@example.com', '123', 'John Doe', '1990-05-15', 'Male', NULL, '1234567890', 2012, 'Employed', NULL, 'alumni'),
(9, 'jane.smith@example.com', '123', 'Jane Smith', NULL, 'Female', NULL, '0987654321', 2014, 'Unemployed', NULL, 'alumni'),
(15, 'ravi.rathod77@gmail.com', '202cb962ac59075b964b07152d234b70', 'Ravi', NULL, NULL, NULL, '9876543210', 2014, NULL, NULL, 'alumni'),
(19, 'email1@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Ravi Rathod M', '2004-12-09', 'Male', 'Not for Admin', '9876543212', 2017, 'Retired', 'photo1.png', 'admin'),
(20, 'ravi.rathod772003@gmail.com', '202cb962ac59075b964b07152d234b70', 'Jagdish M', NULL, NULL, NULL, '9876543210', 2021, NULL, NULL, 'student'),
(21, 'email3@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'kishan B', '2011-02-01', 'Male', 'd23ce170', '9876543210', 2011, 'Employed', 'photo3.png', 'student'),
(22, 'email2@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Vimal m Rathod', '2004-07-07', 'Male', 'D21CE143', '9876543212', 2016, 'Student', 'photo2.png', 'alumni'),
(23, 'tirthraj123@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Tirthraj bhai ', '2004-03-05', 'Male', NULL, '9863576310', 2023, 'Student', NULL, 'student'),
(24, 'alice.wonderland@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Alice Wonderland', '1995-06-01', 'Female', 'd23ce001', '1234567890', 2017, 'Employed', 'alice_profile.jpg', 'alumni'),
(25, 'bob.builder@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Bob Builder', '1989-03-15', 'Male', 'd10ce002', '2345678901', 2010, 'Unemployed', 'bob_profile.jpg', 'alumni'),
(26, 'charlie.brown@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Charlie Brown', '1992-07-21', 'Male', 'd13ce003', '3456789012', 2013, 'Student', 'charlie_profile.jpg', 'student'),
(27, 'daisy.duck@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Daisy Duck', '1994-11-05', 'Female', 'd16ce004', '4567890123', 2016, 'Retired', 'daisy_profile.jpg', 'alumni'),
(28, 'edward.elric@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Edward Elric', '1990-09-18', 'Male', 'd12ce005', '5678901234', 2012, 'Employed', 'edward_profile.jpg', 'alumni'),
(29, 'frank.franklin@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Frank Franklin', '1985-12-25', 'Male', 'd08ce006', '6789012345', 2008, 'Unemployed', 'frank_profile.jpg', 'student'),
(30, 'grace.hopper@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Grace Hopper', '1987-05-01', 'Female', 'd09ce007', '7890123456', 2009, 'Student', 'grace_profile.jpg', 'alumni'),
(31, 'harry.potter@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Harry Potter', '1980-07-31', 'Male', 'd00ce008', '8901234567', 2000, 'Employed', 'harry_profile.jpg', 'alumni'),
(32, 'isabelle.lee@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Isabelle Lee', '1998-02-14', 'Female', 'd22ce009', '9012345678', 2022, 'Student', 'isabelle_profile.jpg', 'student'),
(34, 'kate.bush@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Kate Bush', '1993-08-30', 'Female', 'd15ce011', '1234567890', 1995, 'Employed', 'kate_profile.jpg', 'alumni'),
(35, 'mona.lisa@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Mona Lisa', '1503-06-01', 'Female', 'd1503c012', '2345678901', 0000, 'Retired', 'mona_profile.jpg', 'alumni'),
(36, 'nina.simone@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Nina Simone', '1933-02-21', 'Female', 'd50ce013', '4567890123', 1950, 'Unemployed', 'nina_profile.jpg', 'alumni'),
(37, 'oscar.wilde@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Oscar Wilde', '1854-10-16', 'Male', 'd70ce014', '5678901234', 0000, 'Employed', 'oscar_profile.jpg', 'student'),
(38, 'peter.parker@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Peter Parker', '1995-05-01', 'Male', 'd17ce015', '6789012345', 2017, 'Student', 'peter_profile.jpg', 'student'),
(39, 'quinn.martin@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Quinn Martin', '1999-11-11', 'Female', 'd21ce016', '7890123456', 2021, 'Retired', 'quinn_profile.jpg', 'alumni'),
(40, 'ron.weasley@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Ron Weasley', '1980-03-01', 'Male', 'd00ce017', '8901234567', 2000, 'Employed', 'ron_profile.jpg', 'alumni'),
(41, 'susan.sarandon@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Susan Sarandon', '1946-10-04', 'Female', 'd65ce018', '9012345678', 1965, 'Retired', 'susan_profile.jpg', 'alumni'),
(42, 'tony.stark@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Tony Stark', '1970-05-29', 'Male', 'd92ce019', '0123456789', 1992, 'Employed', 'tony_profile.jpg', 'alumni'),
(43, 'uma.thurman@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Uma Thurman', '1970-04-29', 'Female', 'd95ce020', '1234567890', 1995, 'Student', 'uma_profile.jpg', 'student'),
(44, 'victor.frankl@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Victor Frankl', '1905-03-26', 'Male', 'd28ce021', '2345678901', 1928, 'Retired', 'victor_profile.jpg', 'alumni'),
(45, 'william.shakespeare@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'William Shakespeare', '1564-04-26', 'Male', 'd58ce022', '3456789012', 0000, 'Unemployed', 'will_profile.jpg', 'student'),
(46, 'xena.warrior@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Xena Warrior', '1975-03-15', 'Female', 'd96ce023', '4567890123', 1996, 'Student', 'xena_profile.jpg', 'student'),
(47, 'yoda.master@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Yoda Master', '0896-02-01', 'Male', 'd00ce024', '5678901234', 0000, 'Retired', 'yoda_profile.jpg', 'alumni'),
(48, 'zara.hadid@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Zara Hadid', '1950-10-31', 'Female', 'd75ce025', '6789012345', 1975, 'Employed', 'zara_profile.jpg', 'alumni');
